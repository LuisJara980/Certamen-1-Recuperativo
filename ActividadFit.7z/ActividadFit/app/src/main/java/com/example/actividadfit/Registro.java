package com.example.actividadfit;

public class Registro {
    public String usuario;
    public String actividadDetectada;
    public double latInicio;
    public double lonInicio;
    public double latFin;
    public double lonFin;
    public float distanciaAprox;
    public long timestamp;

    public Registro() { }

    public Registro(String usuario, String actividadDetectada,
                    double latInicio, double lonInicio,
                    double latFin, double lonFin,
                    float distanciaAprox, long timestamp) {
        this.usuario = usuario;
        this.actividadDetectada = actividadDetectada;
        this.latInicio = latInicio;
        this.lonInicio = lonInicio;
        this.latFin = latFin;
        this.lonFin = lonFin;
        this.distanciaAprox = distanciaAprox;
        this.timestamp = timestamp;
    }
}
