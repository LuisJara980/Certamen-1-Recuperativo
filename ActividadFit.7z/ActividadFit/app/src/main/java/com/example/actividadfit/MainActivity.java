package com.example.actividadfit;

import android.Manifest;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private static final int REQ_LOCATION = 100;
    private static final float MIN_DISTANCIA_METROS = 20f;

    private EditText etNombre;
    private Button btnIniciar, btnDetener;
    private TextView tvEstado;

    private FusedLocationProviderClient fusedLocationClient;
    private Location locInicio, locFin;

    private SensorManager sensorManager;
    private Sensor accelerometer;
    private String actividadDetectada = "desconocida";

    private DatabaseReference registrosRef;

    private boolean registrando = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etNombre = findViewById(R.id.etNombre);
        btnIniciar = findViewById(R.id.btnIniciar);
        btnDetener = findViewById(R.id.btnDetener);
        tvEstado = findViewById(R.id.tvEstado);

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        registrosRef = FirebaseDatabase.getInstance().getReference("registros");

        btnIniciar.setOnClickListener(v -> iniciarRegistro());
        btnDetener.setOnClickListener(v -> detenerRegistro());
    }

    private void iniciarRegistro() {
        String nombre = etNombre.getText().toString().trim();
        if (nombre.isEmpty()) {
            Toast.makeText(this, "Nombre obligatorio", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!tienePermisosUbicacion()) {
            solicitarPermisos();
            return;
        }

        if (accelerometer == null) {
            Toast.makeText(this, "No hay acelerómetro disponible", Toast.LENGTH_SHORT).show();
            return;
        }

        obtenerUbicacionInicial();
    }

    private boolean tienePermisosUbicacion() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void solicitarPermisos() {
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                REQ_LOCATION);
    }

    private void obtenerUbicacionInicial() {
        fusedLocationClient.getLastLocation()
                .addOnSuccessListener(location -> {
                    if (location != null) {
                        locInicio = location;
                        registrando = true;
                        tvEstado.setText("Estado: Registro iniciado");
                        Toast.makeText(this, "Inicio registrado", Toast.LENGTH_SHORT).show();

                        btnIniciar.setEnabled(false);
                        btnDetener.setEnabled(true);

                        sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
                    } else {
                        Toast.makeText(this, "No se pudo obtener ubicación inicial", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void detenerRegistro() {
        if (!registrando) {
            Toast.makeText(this, "No hay registro en curso", Toast.LENGTH_SHORT).show();
            return;
        }

        fusedLocationClient.getLastLocation()
                .addOnSuccessListener(location -> {
                    if (location != null) {
                        locFin = location;
                        registrarActividad();
                    } else {
                        Toast.makeText(this, "No se pudo obtener ubicación final", Toast.LENGTH_SHORT).show();
                    }
                });

        sensorManager.unregisterListener(this);
    }

    private void registrarActividad() {
        if (locInicio == null || locFin == null) {
            Toast.makeText(this, "Faltan datos de ubicación", Toast.LENGTH_SHORT).show();
            return;
        }

        float distancia = locInicio.distanceTo(locFin); // en metros

        if (distancia < MIN_DISTANCIA_METROS) {
            tvEstado.setText("Estado: Actividad NO registrada (< 20m)");
            Toast.makeText(this, "Actividad muy corta, no registrada", Toast.LENGTH_LONG).show();
        } else {
            String nombre = etNombre.getText().toString().trim();
            long ahora = System.currentTimeMillis();

            Registro reg = new Registro(
                    nombre,
                    actividadDetectada,
                    locInicio.getLatitude(),
                    locInicio.getLongitude(),
                    locFin.getLatitude(),
                    locFin.getLongitude(),
                    distancia,
                    ahora
            );

            String id = registrosRef.push().getKey();
            if (id != null) {
                registrosRef.child(id).setValue(reg)
                        .addOnSuccessListener(unused -> {
                            tvEstado.setText("Estado: Actividad registrada OK");
                            Toast.makeText(this, "Registro guardado en Firebase", Toast.LENGTH_SHORT).show();
                        })
                        .addOnFailureListener(e -> {
                            tvEstado.setText("Estado: Error al guardar");
                            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                        });
            }
        }

        registrando = false;
        btnIniciar.setEnabled(true);
        btnDetener.setEnabled(false);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (!registrando) return;

        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            float x = event.values[0];
            float y = event.values[1];
            float z = event.values[2];

            double magnitud = Math.sqrt(x * x + y * y + z * z);

            if (magnitud > 15) {
                actividadDetectada = "correr";
            } else if (magnitud > 11) {
                actividadDetectada = "caminar";
            } else {
                actividadDetectada = "quieto";
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // no usado
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (registrando && accelerometer != null) {
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                iniciarRegistro();
            } else {
                Toast.makeText(this, "Permiso de ubicación requerido", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
